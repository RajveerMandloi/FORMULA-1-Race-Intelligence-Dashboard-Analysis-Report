# Data Quality Summary

**Project:** FORMULA 1 Race Intelligence Dashboard Analysis Report (2010–2026)  
**Student:** Rajveer Mandloi | **Team ID:** SWUID2026404163  
**Source:** `data/F1_Racing_Project_Dataset.xlsx`  
**Audit date:** 28 October 2026

## Workbook profile

| Sheet | Rows | Columns | Blank cells | Full-row duplicates |
|---|---:|---:|---:|---:|
| circuits | 29 | 9 | 0 | 0 |
| championship_standings | 311 | 10 | 0 | 0 |
| lap_intelligence | 3,814 | 14 | 0 | 0 |
| qualifying_results | 3,130 | 16 | 0 | 0 |
| race_results | 6,464 | 42 | 13,386 | 0 |

Counts are based on the supplied workbook. Duplicate counts check exact duplicate rows only; they do not establish that all business keys are unique.

## Recommended follow-up checks
1. Profile missing values column by column in `race_results`.
2. Check uniqueness of expected keys such as season/driver/position and race/driver.
3. Verify numeric and date types, especially race dates, times and flags.
4. Review 2026 season coverage before drawing full-season conclusions.
5. Validate Tableau calculations against direct source aggregations.
6. Check join cardinality before relating sheets in Tableau.

## Interpretation
Blank cells may represent fields that do not apply, values not recorded, or missing data. Do not replace blanks with zero unless the field's meaning and analysis method justify it. This audit is a structural check, not proof that every field is factually correct.
