# Dashboard Screenshots

Add screenshots exported from the actual Tableau workbook. Suggested filenames:
- `01_overview.png`
- `02_championship_trends.png`
- `03_qualifying_vs_finish.png`
- `04_lap_and_tyre_analysis.png`

Do not use mock screenshots as evidence of an implemented dashboard.
