# Dataset Dictionary

Source file: `data/F1_Racing_Project_Dataset.xlsx`

## `circuits` (29 rows, 9 columns)
- `circuit_id`: circuit identifier
- `circuit_name`: circuit name
- `country`, `city`: location
- `laps`: circuit lap count
- `lap_km`: lap length in kilometres
- `type`: circuit type as provided
- `altitude_m`: altitude in metres
- `direction`: direction as provided

## `championship_standings` (311 rows, 10 columns)
- `season`: championship season
- `driver_position`: standings position
- `driver`, `team`: competitor/team labels
- `points`, `wins`, `podiums`, `pole_positions`, `dnfs`: season-level performance measures
- `champion`: champion indicator/label as supplied

## `lap_intelligence` (3,814 rows, 14 columns)
- `race_id`, `season`, `circuit_id`: race/season/circuit identifiers
- `lap_number`, `driver`: lap and driver
- `lap_time_s`, `sector1_s`, `sector2_s`, `sector3_s`: time measures in seconds
- `tyre_compound`, `tyre_age_laps`: tyre fields
- `drs_active`: DRS flag as supplied
- `speed_trap_kmh`: speed-trap measure in km/h
- `is_pit_lap`: pit-lap indicator

## `qualifying_results` (3,130 rows, 16 columns)
Includes race/season/round/circuit identifiers, qualifying position, driver/team, Q1/Q2/Q3 lap times, gap to pole, tyre compound, sector times and top speed. Confirm how missing Q1/Q2/Q3 values are represented before comparing sessions.

## `race_results` (6,464 rows, 42 columns)
Includes race/circuit/date/condition fields, grid and finish positions, positions gained, driver/team, points, DNF details, fastest-lap indicator, gap to leader, race time, pit stops, tyre strategy, undercut/overcut attempts, DRS overtakes and laps led. Several columns contain blanks; inspect each field before aggregating.

## Modeling caution
Before joining sheets, verify key uniqueness and join cardinality. Candidate keys may include `race_id`, `circuit_id`, `season`, `driver` and `team`, depending on the analysis. Joining one-to-many sheets without care can multiply rows and inflate points or counts.
