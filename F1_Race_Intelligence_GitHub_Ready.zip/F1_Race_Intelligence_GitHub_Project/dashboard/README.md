# Tableau Workbook

Add the actual Tableau workbook here as `.twb` or `.twbx`. The workbook was not included with the supplied template archives, so this folder intentionally contains instructions rather than a fabricated workbook.

Before publishing, verify the Excel data source path, calculations, filters, chart totals and dashboard render behavior.
