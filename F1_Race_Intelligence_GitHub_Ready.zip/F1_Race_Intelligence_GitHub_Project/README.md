# FORMULA 1 Race Intelligence Dashboard Analysis Report (2010–2026)

**Student:** Rajveer Mandloi  
**Team ID:** SWUID2026404163  
**Institution:** Medicaps University  
**Branch:** CSE  
**Dashboard tool:** Tableau  
**Project purpose:** College submission and GitHub portfolio

## Overview
An interactive Tableau analytics project for exploring Formula 1 race results, qualifying performance, championship standings, lap-level pace, tyre strategy, pit stops, circuit characteristics and race conditions across the supplied 2010–2026 dataset.

The project explores season-level championship performance and race-level patterns using the five sheets in the supplied Excel workbook. The repository includes project-phase documents, a dataset inventory, data-quality notes, a final report, and demonstration planning documents.

## Dataset
File: `data/F1_Racing_Project_Dataset.xlsx`

| Sheet | Rows | Columns | Main themes |
|---|---:|---:|---|
| `circuits` | 29 | 9 | Circuit, location, distance, type, altitude, direction |
| `championship_standings` | 311 | 10 | Season standings, points, wins, podiums, poles, DNFs |
| `lap_intelligence` | 3,814 | 14 | Lap/sector times, tyre compound/age, DRS, speed trap |
| `qualifying_results` | 3,130 | 16 | Qualifying positions/times, gap to pole, sector times, speed |
| `race_results` | 6,464 | 42 | Race outcomes, conditions, positions, points, pit stops, strategy |

The season-bearing sheets contain season values from 2010 through 2026. Treat 2026 as potentially partial and verify coverage before comparing it with completed seasons.

## Suggested analysis questions
1. How do championship points and wins change by season?
2. Which drivers and teams lead in a selected season?
3. How does qualifying position relate to finishing position?
4. Which drivers gain or lose positions from grid to finish?
5. How do lap times and sector splits vary by lap, driver or circuit?
6. How are tyre compound and tyre age associated with lap-time variation?
7. How do pit-stop counts and pit-stop time fields compare?
8. How do weather and safety-car fields vary across races?

## Repository structure
- `01_Ideation_Phase/` — brainstorming, problem statements, empathy map
- `02_Requirement_Analysis/` — requirements, technology stack, data flow, user journey
- `03_Project_Design/` — proposal, solution architecture, problem–solution fit
- `04_Project_Planning/` — backlog and sprint-planning template with project notes
- `05_Project_Development/` — dashboard/story/data preparation documentation
- `06_Performance_Testing/` — performance test templates and validation checklist
- `07_Project_Documentation/` — final project report
- `08_Project_Demonstration/` — demo planning, feature verification and future plan
- `data/` — supplied Excel workbook
- `dashboard/` — add the actual Tableau workbook here
- `screenshots/` — add genuine screenshots exported from Tableau

## Open in Tableau
1. Open Tableau Desktop or Tableau Public.
2. Connect to `data/F1_Racing_Project_Dataset.xlsx`.
3. Review the sheets and verify field types and relationships before building views.
4. Create worksheets and dashboards from validated metrics.
5. Save the workbook in `dashboard/` as `.twb` or `.twbx`.
6. Capture genuine screenshots and add them to `screenshots/`.
7. Update this README with verified dashboard screenshots, findings and any public Tableau link.

## Data quality notes
The workbook has no full-row duplicate records in the supplied sheets. The `race_results` sheet contains 13,386 blank cells across its 6,464 rows and 42 columns; profile them by column before deciding how to treat them. A blank must not automatically be treated as zero. See `DATA_QUALITY_SUMMARY.md`.

## Accuracy and scope
The Tableau workbook and its actual screenshots were not included with the uploaded project template archives. Therefore, this repository does not claim that specific charts, performance timings or a public Tableau link have already been verified. Add those artifacts after validating the actual workbook. Snowflake-specific template sections are marked as not applicable to the confirmed Tableau implementation unless a real Snowflake pipeline is later created.

## Student
Rajveer Mandloi — single-member team, Team ID `SWUID2026404163`.


## Note on Snowflake template files
The supplied development phase archive included both Tableau and Snowflake template tracks. Tableau is the confirmed project tool. Snowflake-track documents are retained for completeness and explicitly state that no Snowflake implementation was provided; they should not be treated as proof of a Snowflake deployment.
