# F1 Race Intelligence — Tableau Portfolio Website

A responsive portfolio landing page for **FORMULA 1 Race Intelligence Dashboard Analysis Report (2010–2026)**.

## Project information
- **Student:** Rajveer Mandloi
- **Team ID:** SWUID2026404163
- **University:** Medicaps University
- **Branch:** Computer Science & Engineering (CSE)
- **Visualization:** Tableau Public

## Live Tableau demo
https://public.tableau.com/app/profile/rajveer.mandloi/viz/Book1_17931086169450/Dashboard1?publish=yes

## Run locally
Open `Craftivo/index.html` in a modern browser. The website uses relative local assets and can be previewed without a build step. An internet connection is needed for Google Fonts and the embedded Tableau dashboard.

## Publish with GitHub Pages
1. Extract this ZIP.
2. Open the `Craftivo` folder and upload its contents (including `index.html` and `assets/`) to the root of a new GitHub repository.
3. In GitHub, go to **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Wait for GitHub Pages to publish. Your website URL will be shown in the Pages settings.

The GitHub Pages URL does not exist until the project is uploaded and Pages is enabled. The Tableau Public link above is the current dashboard demo link.

## Dataset subject areas
The supplied dataset workbook includes sheets for circuits, championship standings, lap intelligence, qualifying results and race results. Validate the workbook's actual season coverage and metrics before reporting numerical findings.

## Template attribution
This site was adapted from the user-provided Craftivo BootstrapMade template. Keep and review the original template's license/attribution terms in `Craftivo/Readme.txt` before public redistribution.
