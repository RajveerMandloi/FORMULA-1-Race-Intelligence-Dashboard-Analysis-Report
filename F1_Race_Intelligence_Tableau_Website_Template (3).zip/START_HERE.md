# Start here

1. Open `Craftivo/index.html` to preview the customized F1 project website.
2. Read `README_GITHUB_PAGES.md` for publishing steps.
3. For GitHub Pages, upload the *contents* of the `Craftivo` folder to the repository root.
4. Tableau demo: https://public.tableau.com/app/profile/rajveer.mandloi/viz/Book1_17931086169450/Dashboard1?publish=yes
