# F1 Race Intelligence Dashboard Analysis Report (2010–2026)

**Student:** Rajveer Mandloi  
**Team ID:** SWUID2026404163  
**University:** Medicaps University  
**Branch:** CSE  
**Dashboard tool:** Tableau

## Folder guide
- `F1_Race_Intelligence_GitHub_Project/` — organized project files intended for GitHub.
- `00_Original_Submitted_Files_Extracted/` — all files extracted from the eight original phase ZIPs, preserved separately.
- `00_Original_Submitted_ZIP_Files/` — original uploaded ZIPs for backup/reference.
- `F1_Racing_Project_Dataset_Original.xlsx` — original dataset copy.

Before submitting, add the actual Tableau workbook (`.twb`/`.twbx`) and real dashboard screenshots if available. Do not claim test results that have not been measured.
